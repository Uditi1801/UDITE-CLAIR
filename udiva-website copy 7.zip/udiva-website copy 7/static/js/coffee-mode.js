const coffeeToggle = document.getElementById("coffeeToggle");

coffeeToggle.addEventListener("click", () => {
    document.body.classList.toggle("coffee");
});
